#!/bin/sh
OPTS=-use-network=false
../../bin/mxmlc $OPTS catalog.mxml
