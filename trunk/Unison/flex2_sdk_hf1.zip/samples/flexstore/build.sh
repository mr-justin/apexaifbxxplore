#!/bin/sh
OPTS=-use-network=false
../../bin/mxmlc $OPTS flexstore.mxml
../../bin/mxmlc $OPTS beige.css
../../bin/mxmlc $OPTS blue.css
