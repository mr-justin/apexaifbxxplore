#!/bin/sh
OPTS=-use-network=true
../../bin/mxmlc $OPTS finder.mxml
../../bin/mxmlc $OPTS recentReviews.mxml
